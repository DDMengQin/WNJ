## 效果预览
[效果预览](https://htmlpreview.github.io/?https://github.com/geekape/geek-navigation/blob/master/index.html)
## 极客猿梦导航站图片演示
<img src="http://www.zcbboke.com/wp-content/uploads/2018/01/geeknav.gif"/>

<h2>项目模仿</h2>
<a href="http://www.alloyteam.com/nav/">腾讯AlloyTeam前端团队导航</a>
写码不易，如果些项目对你有用，请帮忙点颗星（star)
<h2>极客猿梦导航站特色</h2>
<ul>
  <li>简洁好看的风格</li>
  <li>响应式布局，兼容4个尺寸设备</li>
  <li>有手机端的菜单</li>
  <li>支持导航锚点定位</li>
</ul>
